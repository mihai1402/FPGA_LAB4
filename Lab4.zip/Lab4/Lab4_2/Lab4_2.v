module Lab4_2 (
    input wire clk,          // 50 MHz board clock
    output reg rf_out
);

    parameter SONG_LENGTH = 46053;
    reg [5:0] memory [0:SONG_LENGTH-1];
    
    initial $readmemh("voce.mem", memory);

    reg [12:0] sample_timer = 0;   // Counts to 6249 for 8 kHz audio sampling
    reg [15:0] address = 0;        // Points to the current song sample
    reg [5:0] current_volume = 0;  // Holds the 6-bit volume level (0-63)
    reg [5:0] pwm_counter = 0;     // Counts to 63 for 781.25 kHz carrier

    always @(posedge clk) begin
        // --- AM CARRIER & PWM MODULATION ---
        // 50 MHz / 64 = 781.25 kHz carrier wave
        pwm_counter <= pwm_counter + 1; 
        
        if (pwm_counter < current_volume) 
            rf_out <= 1;
        else 
            rf_out <= 0;

        // --- AUDIO SAMPLING (8 kHz) ---
        // 50 MHz / 8000 Hz = 6250 clock cycles per audio sample
        if (sample_timer == 6249) begin
            sample_timer <= 0;
            
            if (address == SONG_LENGTH - 1)
                address <= 0;
            else
                address <= address + 1;
                
            current_volume <= memory[address];
        end else begin
            sample_timer <= sample_timer + 1;
        end
    end
endmodule