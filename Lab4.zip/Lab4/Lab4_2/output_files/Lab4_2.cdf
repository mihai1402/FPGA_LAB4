/* Quartus Prime Version 25.1std.0 Build 1129 10/21/2025 SC Standard Edition */
JedecChain;
	FileRevision(JESD32A);
	DefaultMfr(6E);

	P ActionCode(Cfg)
		Device PartName(EP4CE10E22) Path("D:/FPGA/Lab4/Lab4_2/output_files/") File("Lab4_2.sof") MfrSpec(OpMask(1));

ChainEnd;

AlteraBegin;
	ChainType(JTAG);
AlteraEnd;
