import wave
import struct

filename = "voce.wav"

with wave.open(filename, "rb") as wav:
    channels = wav.getnchannels()
    sample_width = wav.getsampwidth()
    framerate = wav.getframerate()
    num_frames = wav.getnframes()
    
    print(f"Channels: {channels} (Must be 1)")
    print(f"Sample Rate: {framerate} Hz (Expected 8000)")
    print(f"Bit Depth: {sample_width * 8}-bit (Expected 16)")
    print(f"Total Samples: {num_frames}")

    if channels != 1 or sample_width != 2:
        raise ValueError("Audio must be 16-bit Mono! Re-export from Audacity.")

    raw_data = wav.readframes(num_frames)
    samples = struct.unpack(f"<{num_frames}h", raw_data)

with open("voce.mem", "w") as mem:
    for s in samples:
        # Shift signed 16-bit (-32768..32767) to unsigned (0..65535)
        unsigned = s + 32768
        # Scale to 6-bit (0..63)
        val = min(63, max(0, unsigned >> 10))
        # Format as standard hex
        mem.write(f"{val:X}\n")

print(f"\nDone! Set 'parameter SONG_LENGTH = {num_frames};' in your Verilog code.")